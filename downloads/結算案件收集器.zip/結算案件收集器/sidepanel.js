const STORAGE_KEY = 'collectedRecords';

const btnAdd    = document.getElementById('btnAdd');
const btnClear  = document.getElementById('btnClear');
const btnRead   = document.getElementById('btnRead');
const fileInput = document.getElementById('fileInput');
const btnExport = document.getElementById('btnExport');
const btnCopyJson = document.getElementById('btnCopyJson');
const statusDiv = document.getElementById('status');
const tbody     = document.getElementById('tbody');
const emptyMsg  = document.getElementById('emptyMsg');
const jsonView  = document.getElementById('jsonView');
const tabBtns   = document.querySelectorAll('.tab-btn');
const tabPanels = { list: document.getElementById('tabList'), json: document.getElementById('tabJson') };

let records = [];

// 受理案件識別鍵：受理日期＋受理號碼起＋受理號碼迄，同前端 lib/settlement/constructionQuantity.js caseOverrideKey
const acceptKey = r => `${r?.受理日期 || ''}|${r?.受理號碼起 || ''}|${r?.受理號碼迄 || ''}`;

function setStatus(msg, type = 'info') {
  statusDiv.textContent = msg;
  statusDiv.className = type;
}

function renderJsonView() {
  jsonView.textContent = JSON.stringify({ 結算資料: records }, null, 2);
}

tabBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    tabBtns.forEach(b => b.classList.toggle('active', b === btn));
    Object.entries(tabPanels).forEach(([key, panel]) => {
      panel.classList.toggle('active', key === btn.dataset.tab);
    });
    if (btn.dataset.tab === 'json') renderJsonView();
  });
});

function appendCell(tr, text, className) {
  const td = document.createElement('td');
  if (className) td.className = className;
  td.textContent = text;
  tr.appendChild(td);
  return td;
}

function renderTable() {
  renderJsonView();
  tbody.innerHTML = '';
  const hasData = records.length > 0;
  emptyMsg.style.display = hasData ? 'none' : 'block';
  btnClear.disabled  = !hasData;
  btnExport.disabled = !hasData;

  records.forEach((rec, idx) => {
    const 受理 = rec.受理資料 || {};
    const tr = document.createElement('tr');
    tr.draggable = true;
    tr.dataset.idx = idx;
    // 逐格以 textContent 寫入，不以樣板字串組成 innerHTML：這些欄位的內容來自
    // content.js 自 BUG500 頁面 DOM 擷取的文字（亦可能來自使用者匯入的 JSON 檔），
    // 內含 `<` 等字元時會被解析為標記，並在側邊欄的權限環境下執行
    appendCell(tr, '⠿', 'drag-handle');
    appendCell(tr, String(idx + 1));
    appendCell(tr, 受理.受理日期 || '');
    appendCell(tr, 受理.受理號碼起 || '');
    appendCell(tr, 受理.受理號碼迄 || '');
    appendCell(tr, 受理.申請人 || '');

    const delCell = document.createElement('td');
    const delBtn = document.createElement('button');
    delBtn.className = 'btn-del';
    delBtn.dataset.idx = idx;
    delBtn.textContent = '刪除';
    delCell.appendChild(delBtn);
    tr.appendChild(delCell);

    tbody.appendChild(tr);
  });

  tbody.querySelectorAll('.btn-del').forEach(btn => {
    btn.addEventListener('click', () => {
      records.splice(parseInt(btn.dataset.idx, 10), 1);
      saveAndRender();
    });
  });

  tbody.querySelectorAll('tr').forEach(tr => {
    tr.addEventListener('dragstart', handleDragStart);
    tr.addEventListener('dragover', handleDragOver);
    tr.addEventListener('dragleave', handleDragLeave);
    tr.addEventListener('drop', handleDrop);
    tr.addEventListener('dragend', handleDragEnd);
  });
}

let dragSrcIdx = null;

function handleDragStart(e) {
  dragSrcIdx = parseInt(e.currentTarget.dataset.idx, 10);
  e.currentTarget.classList.add('dragging');
  e.dataTransfer.effectAllowed = 'move';
  e.dataTransfer.setData('text/plain', String(dragSrcIdx));
}

function handleDragOver(e) {
  e.preventDefault();
  e.dataTransfer.dropEffect = 'move';
  e.currentTarget.classList.add('drag-over');
}

function handleDragLeave(e) {
  e.currentTarget.classList.remove('drag-over');
}

function handleDrop(e) {
  e.preventDefault();
  e.currentTarget.classList.remove('drag-over');
  const targetIdx = parseInt(e.currentTarget.dataset.idx, 10);
  if (dragSrcIdx === null || dragSrcIdx === targetIdx) return;

  const [moved] = records.splice(dragSrcIdx, 1);
  records.splice(targetIdx, 0, moved);
  dragSrcIdx = null;
  saveAndRender();
}

function handleDragEnd(e) {
  e.currentTarget.classList.remove('dragging');
  tbody.querySelectorAll('tr').forEach(tr => tr.classList.remove('drag-over'));
}

function saveAndRender() {
  chrome.storage.local.set({ [STORAGE_KEY]: records }, renderTable);
}

chrome.storage.local.get(STORAGE_KEY, result => {
  records = result[STORAGE_KEY] || [];
  renderTable();
});

btnAdd.addEventListener('click', async () => {
  setStatus('讀取中...', 'info');
  btnAdd.disabled = true;

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js']
    });

    chrome.tabs.sendMessage(tab.id, { action: 'extract' }, response => {
      btnAdd.disabled = false;

      if (chrome.runtime.lastError) {
        setStatus('無法連線，請重新整理頁面後再試。', 'error');
        return;
      }
      if (!response || !response.success) {
        setStatus('擷取失敗：' + (response?.error || '未知錯誤'), 'error');
        return;
      }

      const data = response.data;
      const 受理號碼起 = data.受理資料?.受理號碼起 || '';

      if (!受理號碼起) {
        setStatus('目前頁面非受理資料頁面，無法讀取受理資料', 'error');
        return;
      }

      const key = acceptKey(data.受理資料);
      const duplicate = records.some(r => acceptKey(r.受理資料) === key);
      if (duplicate) {
        setStatus(`受理案件 ${data.受理資料?.受理日期} ${受理號碼起} 已存在`, 'error');
        return;
      }

      records.push(data);
      saveAndRender();
      setStatus(`已加入：${data.受理資料?.受理日期} ${受理號碼起}`, 'ok');
    });
  } catch (e) {
    btnAdd.disabled = false;
    setStatus('錯誤：' + e.message, 'error');
  }
});

btnClear.addEventListener('click', () => {
  if (!confirm(`確定清除全部 ${records.length} 筆資料？`)) return;
  records = [];
  saveAndRender();
  setStatus('已清除所有資料', 'info');
});

btnRead.addEventListener('click', () => {
  fileInput.value = '';
  fileInput.click();
});

fileInput.addEventListener('change', () => {
  const file = fileInput.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = () => {
    let parsed;
    try {
      parsed = JSON.parse(reader.result);
    } catch (e) {
      setStatus('檔案格式錯誤，不是有效的 JSON', 'error');
      return;
    }

    const incoming = Array.isArray(parsed.結算資料) ? parsed.結算資料 : null;
    if (!incoming) {
      setStatus('檔案內容格式不符（缺少「結算資料」陣列）', 'error');
      return;
    }

    let added = 0, skipped = 0;
    incoming.forEach(rec => {
      const 受理號碼起 = rec.受理資料?.受理號碼起 || '';
      const duplicate = 受理號碼起 && records.some(r => acceptKey(r.受理資料) === acceptKey(rec.受理資料));
      if (duplicate) {
        skipped++;
      } else {
        records.push(rec);
        added++;
      }
    });

    saveAndRender();
    setStatus(`已讀取 ${added} 筆${skipped ? `，跳過重複 ${skipped} 筆` : ''}`, 'ok');
  };
  reader.onerror = () => setStatus('讀取檔案失敗', 'error');
  reader.readAsText(file);
});

btnCopyJson.addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(jsonView.textContent);
    setStatus('已複製 JSON 到剪貼簿', 'ok');
  } catch (e) {
    setStatus('複製失敗：' + e.message, 'error');
  }
});

btnExport.addEventListener('click', () => {
  if (records.length === 0) return;
  const json = JSON.stringify({ 結算資料: records }, null, 2);
  const now = new Date();
  const ts = `${now.getFullYear()}${String(now.getMonth()+1).padStart(2,'0')}${String(now.getDate()).padStart(2,'0')}`;
  const filename = `受理資料_${ts}.json`;
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
  setStatus(`已下載：${filename}（${records.length} 筆）`, 'ok');
});
