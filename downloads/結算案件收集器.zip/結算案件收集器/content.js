function validatePage() {
  const required = ['受理主檔', '物料檔', '工程費', '施工檔'];
  const bodyText = document.body.innerText;
  const missing = required.filter(k => !bodyText.includes(k));
  return missing;
}

function extractData() {
  const missing = validatePage();
  if (missing.length > 0) {
    throw new Error('頁面錯誤');
  }

  const tables = document.querySelectorAll('table');

  function readTable(table) {
    const data = {};
    if (!table) return data;
    table.querySelectorAll('tr').forEach(row => {
      const cells = row.querySelectorAll('td, th');
      const labels = [], values = [];
      cells.forEach((cell, i) => {
        const inp = cell.querySelector('input');
        const val = inp ? inp.value.trim() : cell.innerText.trim();
        if (i % 2 === 0) labels.push(val);
        else values.push(val);
      });
      labels.forEach((l, i) => { if (l) data[l] = values[i] || ''; });
    });
    return data;
  }

  const topData = readTable(tables[2]);

  const 起El = document.getElementById('txt_NO1_1');
  const 迄El = document.getElementById('txt_NO2_1');
  const 水號El = document.getElementById('txt_WaterNo');
  const 受理號碼起 = 起El ? 起El.value.trim() : (topData['受理號碼'] || '');

  const 受理資料 = {
    受理日期: topData['受理日期'] || '',
    受理號碼起: 受理號碼起,
    受理號碼迄: 迄El ? 迄El.value.trim() : 受理號碼起,
    受理種類: topData['受理種類'] || '',
    水號: 水號El ? 水號El.value.trim() : (topData['水    號'] || ''),
    申請人: topData['用 戶 名'] || '',
    裝置地址: topData['裝置地址'] || '',
  };

  const matItems = [];
  if (tables[5]) {
    tables[5].querySelectorAll('tr').forEach((row, idx) => {
      if (idx < 3) return;
      const r = [];
      row.querySelectorAll('td, th').forEach(cell => {
        const inp = cell.querySelector('input');
        r.push(inp ? inp.value.trim() : cell.innerText.trim());
      });
      if (r.length < 2 || r[0] === '加總') return;
      matItems.push({
        代號: r[1], 名稱: r[2], 規格: r[3],
        單價: r[5], 設計數量: r[6], 設計金額: r[7],
        結算數量: r[8], 結算金額: r[9],
      });
    });
  }

  const engItems = [];
  if (tables[6]) {
    tables[6].querySelectorAll('tr').forEach((row, idx) => {
      if (idx < 3) return;
      const r = [];
      row.querySelectorAll('td, th').forEach(cell => {
        const inp = cell.querySelector('input');
        r.push(inp ? inp.value.trim() : cell.innerText.trim());
      });
      if (r.length < 2 || r[0] === '加總' || !r[5]) return;
      engItems.push({
        種類: r[1], 大類: r[3], 名稱: r[5],
        單價: r[8], 設計數量: r[9], 設計金額: r[10],
        結算數量: r[11], 結算金額: r[12],
      });
    });
  }

  const conItems = [];
  if (tables[7]) {
    tables[7].querySelectorAll('tr').forEach((row, idx) => {
      if (idx < 3) return;
      const r = [];
      row.querySelectorAll('td, th').forEach(cell => {
        const inp = cell.querySelector('input');
        r.push(inp ? inp.value.trim() : cell.innerText.trim());
      });
      if (r.length < 2 || r[0] === '加總') return;
      const itemConNo = r[1];
      conItems.push({
        代號: r[2], 名稱: r[3],
        單位: r[6],
        單價: r[8], 設計數量: r[9], 設計金額: r[10],
        結算數量: r[11], 結算金額: r[12],
        合約編號: itemConNo,
      });
    });
  }

  return { 受理資料, 物料檔: matItems, 工程費: engItems, 施工檔: conItems };
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'extract') {
    try {
      const data = extractData();
      sendResponse({ success: true, data });
    } catch (e) {
      sendResponse({ success: false, error: e.message });
    }
  }
  return true;
});
